# Shahin Siddique — Personal Portfolio

A modern, premium, recruiter-friendly personal portfolio website for **Shahin Siddique**, B.Tech Computer Science & Design graduate (2025) and aspiring Software Engineer / Data Analyst / AI Developer.

## Features

- Dark modern theme with blue/purple gradients and glassmorphism
- Fully responsive (mobile-first)
- Animated particle background
- Smooth scroll, active nav indicator, scroll-to-top
- Project filtering (All / Analytics / AI / Web)
- Dark / Light mode toggle
- Contact form with client-side validation
- SEO & Open Graph metadata
- Accessible focus states and reduced-motion support
- Editable data constants (`data.js`)

## Sections

1. Hero  
2. About Me  
3. Skills  
4. Featured Projects (RetailPulse, Aether, Biriyani Lover)  
5. Data Analytics workflow  
6. Education timeline  
7. Resume download card  
8. GitHub / LinkedIn cards  
9. Contact form  
10. Footer  

## Quick Start

Open `index.html` in a browser, or serve locally:

```bash
# Using Python
python -m http.server 8080

# Using npx
npx serve .
```

Then visit `http://localhost:8080`.

## Customization

### Personal details & links
Edit the values in `index.html` or use `data.js` as the single source of truth for:

- Name, title, tagline, about text
- LinkedIn, GitHub, Email URLs
- Resume PDF path (`/resume.pdf` — replace with real file)
- Project Live Demo & GitHub links
- Education details

### Resume
Place your real resume PDF in the root (or update the `href` on the Download / View Resume buttons).

### Colors & theme
Tailwind config is inlined in `index.html`. Primary accents use indigo/purple.

## Tech Stack

- HTML5 + CSS3 + Vanilla JavaScript
- Tailwind CSS (CDN)
- Lucide Icons
- Canvas particle system
- No build step required — production-ready as static files

## Notes for recruiters

- All content is accurate to the provided brief.
- No fabricated work experience, certificates, or company logos.
- Projects demonstrate practical skills in analytics dashboards, AI-assisted UIs, and responsive web development.

## License

Personal portfolio — © 2026 Shahin Siddique.
